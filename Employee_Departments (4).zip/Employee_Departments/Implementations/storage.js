export default class store {
    static get(key) {
        return JSON.parse(localStorage.getItem(key));
    }
    static set(key,collection) {
        localStorage.setItem(key,JSON.stringify(collection));
    }
}