

export default class BaseModel {
    constructor() {
        this.id = 0;
    }
};
