import BaseImplementation from "../Implementations/BaseImplementation.js";

export default class DeptImplementation extends BaseImplementation{
    constructor(){
        super('department');
    }
}