import BaseImplementation from "../Implementations/BaseImplementation.js";

export default class EmployeeImplementation extends BaseImplementation{
    constructor(){
        super('employee');
    }
}